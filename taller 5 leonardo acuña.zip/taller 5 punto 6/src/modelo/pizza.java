/*
 */
package modelo;
public class pizza {
    private static int totalPedidas = 0;
    private static int totalServidas = 0;
  public static int getTotalPedidas(){
    return totalPedidas;
  }
  public static int getTotalServidas(){
    return totalServidas;
  }
  private int tamano; 
  private int tipo; 
  private int estado; 
  public pizza (String tip, String tam){
    switch(tip){
      case "cuatro quesos": this.tipo = 1; break;
      case "funghi": this.tipo = 2; break;
      case "margarita": this.tipo = 0; break;
      default: System.out.println("No existe este tipo de Pizza.");
    }
    switch(tam){
      case "mediana": this.tamano = 0; break;
      case "familiar": this.tamano = 1; break;
      default: System.out.println("No tenemos ese tamaño de Pizza.");
    }
    this.estado = 0;
    totalPedidas++;
  }
  public void sirve(){
    if (this.estado == 1){
      System.out.println("Esta pizza ya ha sido servida.");
    } else {
      this.estado = 1;
      totalServidas++;
    }
  }
  public String toString(){
    String p = "pizza";
    switch (this.tipo){
        case 1: p += " Cuatro Quesos"; break;
        case 2: p += " Funghi"; break;
        default: p += " Margarita";
    }
    if (this.tamano > 0) {       
        p += " familiar,";
    } else {    
        p += " mediana,";
    }
    if (this.estado > 0) {    
        p += " servida";
    } else {  
        p += " pedida";
    }
    return p;
  }
}
