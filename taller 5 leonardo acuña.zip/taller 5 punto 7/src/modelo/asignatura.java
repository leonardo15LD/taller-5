/*
Crear la clase asignatura con atributos para el nombre y código. De una misma asignatura se puede crear máximo tres
grupos, en caso tal, para cada grupo se debe registrar el número del grupo, el docente a cargo y el listado de estudiantes
inscritos que no puede ser mayor de 3. Para cada estudiante se debe registrar su primer nombre y su primer apellido,
sus notas de p1, p2 y p3. Para cada clase desarrollada incluir métodos habituales. Crear una clase principal, en la
que se pueda crear una asignatura, registrar los grupos deseados con sus estudiantes, y luego imprima los datos de la
asignatura, el listado de estudiantes por grupo en orden por promedio y en orden por apellido (el usuario debe
seleccionar la opción deseada).
 */
package modelo;
import java.util.Scanner;
public class asignatura {
    Scanner entrada= new Scanner(System.in);
    private String nombre_asig,codigo_asig;
    private int num_grupos;
  
    public asignatura(){
        this.nombre_asig="matematicas";
        this.codigo_asig="0500A";
    }
    public int getNum_grupos() {
        return num_grupos;
    }
    public void setNum_grupos(int num_grupos) {
        this.num_grupos = num_grupos;
    }
    public String getNombre_asig() {
        return nombre_asig;
    }
    public void setNombre_asig(String nombre_asig) {
        this.nombre_asig = nombre_asig;
    }
    public String getCodigo_asig() {
        return codigo_asig;
    }
    public void setCodigo_asig(String codigo_asig) {
        this.codigo_asig = codigo_asig;
    }
    public void crearGrupos(){
        System.out.println("nombre asignatura: "+getNombre_asig());
        System.out.println("codigo asignatura: "+getCodigo_asig());

    }  
}
