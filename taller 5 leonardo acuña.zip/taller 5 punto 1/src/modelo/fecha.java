/*
Desarrolle una clase Persona, con atributos para sus datos personales, dentro de los cuales se debe incluir la fecha de
nacimiento (que es un objeto de la clase Fecha con atributos para el día, mes y año), dirección de domicilio y dirección
de trabajo (que son objetos de la clase Dirección, con los atributos que usted considere necesarios). En la clase
principal, cree varios objetos personas y muestre sus datos.
 */
package modelo;

public class fecha {
    private String dia,mes,año;
    
    public fecha (){
        this.dia="20";
        this.año="2003";
        this.mes="novimbre";
    }
    public fecha (String dia,String mes,String año){
        this.dia=dia;
        this.año=año;
        this.mes=mes;
    }
    public String getDia(){
        return this.dia;
    }
    public String getAño(){
        return this.año;
    }
    public String getMes(){
        return this.mes;
    }
    public void setDia(String dia){
        this.dia=dia;
    }
    public void setAño(String año){
        this.año=año;
    }
    public void setMes(String mes){
        this.mes=mes;
    } 
    public void imprimirfecha(String dia,String mes,String año){
        System.out.println("fecha de nacimiento ");
        System.out.println("Dia: "+getDia()+" mes: "+getMes()+" año: "+getAño());
    }
    public void imprimirfecha(){
        imprimirfecha(getDia(),getMes(),getAño());
    }
}
 
