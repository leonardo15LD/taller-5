/*
Desarrolle una clase Persona, con atributos para sus datos personales, dentro de los cuales se debe incluir la fecha de
nacimiento (que es un objeto de la clase Fecha con atributos para el día, mes y año), dirección de domicilio y dirección
de trabajo (que son objetos de la clase Dirección, con los atributos que usted considere necesarios). En la clase
principal, cree varios objetos personas y muestre sus datos.
 */
package modelo;
public class direccion {
    private String carrera,carrera2;
    private String barrio,barrio2;
    private String calle,calle2;
    public  direccion(){
        this.carrera="10";
        this.barrio="el socorro";
        this.calle="25";
        this.carrera2="11";
        this.barrio2="el coco";
        this.calle2="24";
    }
    public  direccion(String calle,String carrera,String barrio,String calle2,String carrera2,String barrio2){
        this.carrera=carrera;
        this.barrio=barrio;
        this.calle=calle;
        this.carrera2=carrera2;
        this.barrio2=barrio2;
        this.calle2=calle2;
    }
    public String getCarrera2() {
        return carrera2;
    }
    public void setCarrera2(String carrera2) {
        this.carrera2 = carrera2;
    }
    public String getBarrio2() {
        return barrio2;
    }
    public void setBarrio2(String barrio2) {
        this.barrio2 = barrio2;
    }
    public String getCalle2() {
        return calle2;
    }
    public void setCalle2(String calle2) {
        this.calle2 = calle2;
    }
    public String getCarrera() {
        return carrera;
    }
    public void setCarrera(String carrera) {
        this.carrera = carrera;
    }
    public String getBarrio() {
        return barrio;
    }
    public void setBarrio(String barrio) {
        this.barrio = barrio;
    }
    public String getCalle() {
        return calle;
    }
    public void setCalle(String calle) {
        this.calle = calle;
    }
    public void impPrincipal(){
        System.out.println("calle: "+getCalle()+" carrera: "+getCarrera()+" barrio: "+getBarrio());
    }
    public void impDomicilio(){
        System.out.println("calle: "+getCalle2()+" carrera: "+getCarrera2()+" barrio: "+getBarrio2());
    }
    public void imprimir_direccion(String calle,String carrera,String barrio,String calle2,String carrera2,String barrio2) {
        impDomicilio();
        impPrincipal();
    }
    public void imprimir_direccion(){
        imprimir_direccion(getCalle(),getCarrera(),getBarrio(),getCalle2(),getCarrera2(),getBarrio2());
    }
}