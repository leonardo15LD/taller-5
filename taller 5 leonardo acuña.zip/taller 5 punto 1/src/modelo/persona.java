/*
Desarrolle una clase Persona, con atributos para sus datos personales, dentro de los cuales se debe incluir la fecha de
nacimiento (que es un objeto de la clase Fecha con atributos para el día, mes y año), dirección de domicilio y dirección
de trabajo (que son objetos de la clase Dirección, con los atributos que usted considere necesarios). En la clase
principal, cree varios objetos personas y muestre sus datos.
 */
package modelo;

public class persona {
    private String nombre,apellido;
    public persona(){
        this.nombre="leonardo";
        this.apellido="acuña";
    }
    public persona(String nombre,String apellido){
        this.nombre=nombre;
        this.apellido=apellido;
    }
    public String getNombre(){
        return this.nombre;
    }
    public String getApellido(){
        return this.apellido;
    }
    public void setNombre(){
        this.nombre=nombre;
    }
    public void setApellido(){
        this.apellido=apellido;
    }
    public void datos(String nombre,String apellido){
        System.out.println("nombre: "+getNombre());
        System.out.println("apellido: "+getApellido());
    }
    public void datos(){
        datos(getNombre(),getApellido());
    }
    
}
