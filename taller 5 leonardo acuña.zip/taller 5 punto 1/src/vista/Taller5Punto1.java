/*
Desarrolle una clase Persona, con atributos para sus datos personales, dentro de los cuales se debe incluir la fecha de
nacimiento (que es un objeto de la clase Fecha con atributos para el día, mes y año), dirección de domicilio y dirección
de trabajo (que son objetos de la clase Dirección, con los atributos que usted considere necesarios). En la clase
principal, cree varios objetos personas y muestre sus datos.
 */
package vista;
import modelo.*;
public class Taller5Punto1 {
    public static void main(String[] args) {
        //OBJETO 1
        System.out.println("persona 1");
        persona persona1=new persona("leo", "messi");
        fecha fechaNacimiento= new fecha("21","12","2004");
        persona1.datos();
        //fecha
        fechaNacimiento.imprimirfecha();
        //direccion
        direccion persona_fecha=new direccion();
        persona_fecha.imprimir_direccion();
        //OBJETO 2
        System.out.println("------------------------");
        System.out.println("persona 2");
        persona persona2=new persona() ;
        fecha fechaNacimiento2= new fecha();
        persona2.datos();
        //fecha
        fechaNacimiento2.imprimirfecha();
        //direccion
        direccion persona_fecha2=new direccion("15","29","sabanas","18","27","los mangos");
        persona_fecha2.imprimir_direccion();  
        //OBJETO 3
        System.out.println("------------------------");
        System.out.println("persona 3");
        persona persona3=new persona("cristiano", "ronaldo");
        fecha fechaNacimiento3= new fecha("22","11","2002");
        persona3.datos();
        //fecha
        fechaNacimiento3.imprimirfecha();
        //direccion
        direccion persona_fecha3=new direccion("11","15","las tapas","13","25","los cortes");
        persona_fecha3.imprimir_direccion();
    }
}
